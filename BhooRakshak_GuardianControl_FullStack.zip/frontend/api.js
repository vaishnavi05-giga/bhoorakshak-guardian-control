const API_BASE = localStorage.getItem('bhoorakshak_api') || window.location.origin;
async function api(path, options={}) {
  const r = await fetch(API_BASE + path, {headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options});
  if(!r.ok) throw new Error(`API ${r.status}`);
  return r.json();
}
window.BhooRakshakAPI = {
  base: API_BASE,
  health: ()=>api('/api/health'),
  nodes: ()=>api('/api/nodes'),
  alerts: ()=>api('/api/alerts'),
  predictions: ()=>api('/api/predictions/latest'),
  telemetry: (nodeId, limit=50)=>api(`/api/telemetry/${encodeURIComponent(nodeId)}?limit=${limit}`),
  ingest: (data)=>api('/api/telemetry',{method:'POST',body:JSON.stringify(data)}),
  simulate: (hazard)=>api(`/api/simulate/${hazard}`,{method:'POST'})
};
