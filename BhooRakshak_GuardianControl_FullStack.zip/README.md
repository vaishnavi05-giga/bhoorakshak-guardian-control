# BhooRakshak + Guardian Control Full Stack

Run:
`pip install -r requirements.txt`
`uvicorn main:app --host 0.0.0.0 --port 8000`

Open `http://localhost:8000`.

Guardian Control is backend-persistent: guardians, dispatches, statuses, timestamps and notes are stored in SQLite. High-risk telemetry creates an alert and an automatic dispatch; if an available guardian exists, that guardian is assigned and marked busy. The UI reads live nodes, predictions, alerts, guardians and dispatches from the API and refreshes every 15 seconds.

API: /api/health, /api/nodes, /api/telemetry/{node_id}, /api/predictions/latest, /api/alerts, /api/alerts/{id}/ack, /api/guardians, /api/guardians/{id}/status, /api/dispatches, /api/alerts/{id}/dispatch, /api/dispatches/{id}/status, /api/telemetry, /api/simulate/{hazard}.
