# BhooRakshak + Guardian Control

Full-stack FastAPI + frontend deployment.

## Render
Root Directory: leave empty
Build Command: pip install -r requirements.txt
Start Command: uvicorn main:app --host 0.0.0.0 --port $PORT

## Structure
main.py
requirements.txt
render.yaml
frontend/index.html
frontend/api.js
