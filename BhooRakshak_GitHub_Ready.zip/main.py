from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[2]
DB_PATH = Path(os.getenv("DATABASE_PATH", ROOT / "database" / "bhoorakshak.db"))
FRONTEND = ROOT / "frontend"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="BhooRakshak API", version="1.0.0", description="Sensor-to-prediction API for multi-hazard monitoring.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class Telemetry(BaseModel):
    node_id: str = Field(min_length=1, max_length=64)
    hazard: str = Field(default="conductor", min_length=1, max_length=32)
    latitude: float = 0
    longitude: float = 0
    battery: float = 100
    voltage: float | None = None
    current: float | None = None
    vibration: float | None = None
    water_level: float | None = None
    rain_rate: float | None = None
    temperature: float | None = None
    smoke: float | None = None
    humidity: float | None = None
    pm25: float | None = None
    gas: float | None = None
    aqi: float | None = None
    timestamp: datetime | None = None

HAZARDS = {"conductor", "flood", "fire", "pollution"}

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS nodes (
          node_id TEXT PRIMARY KEY, hazard TEXT NOT NULL, latitude REAL, longitude REAL,
          battery REAL DEFAULT 100, status TEXT DEFAULT 'online', last_seen TEXT
        );
        CREATE TABLE IF NOT EXISTS telemetry (
          id INTEGER PRIMARY KEY AUTOINCREMENT, node_id TEXT NOT NULL, hazard TEXT NOT NULL,
          timestamp TEXT NOT NULL, latitude REAL, longitude REAL, battery REAL,
          payload TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS predictions (
          id INTEGER PRIMARY KEY AUTOINCREMENT, node_id TEXT NOT NULL, hazard TEXT NOT NULL,
          timestamp TEXT NOT NULL, risk REAL NOT NULL, confidence REAL NOT NULL,
          state TEXT NOT NULL, action TEXT NOT NULL, explanation TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS alerts (
          id INTEGER PRIMARY KEY AUTOINCREMENT, node_id TEXT NOT NULL, hazard TEXT NOT NULL,
          timestamp TEXT NOT NULL, severity TEXT NOT NULL, message TEXT NOT NULL,
          acknowledged INTEGER DEFAULT 0
        );
        """)
        if c.execute("SELECT COUNT(*) FROM nodes").fetchone()[0] == 0:
            seeds = [
                ("PL-0042","conductor",12.83,79.97,94),
                ("FL-0018","flood",16.52,80.63,87),
                ("FF-0027","fire",11.63,76.08,91),
                ("PN-0183","pollution",17.39,78.49,76),
            ]
            c.executemany("INSERT INTO nodes VALUES (?,?,?,?,?,'online',?)", [(a,b,x,y,z,now_iso()) for a,b,x,y,z in seeds])

init_db()

def predict(t: Telemetry) -> dict[str, Any]:
    h = t.hazard.lower()
    risk, confidence, action, explanation = 10.0, 88.0, "Monitor", "Signals are stable."
    if h == "conductor":
        score = 0
        if t.voltage is not None and t.voltage < 200: score += 30
        if t.current is not None and t.current < 2: score += 30
        if t.vibration is not None and t.vibration > 1.0: score += 35
        risk = min(98, 10 + score)
        confidence = min(99, 86 + score * 0.15)
        action = "Inspect node" if risk < 70 else "Isolate section"
        explanation = "Voltage/current anomaly and vibration pattern indicate conductor-fault risk." if risk >= 50 else "Electrical and vibration signals are within expected limits."
    elif h == "flood":
        level = t.water_level or 0
        rain = t.rain_rate or 0
        risk = min(98, 8 + level * 0.55 + rain * 1.8)
        confidence = min(98, 84 + risk * .08)
        action = "Issue warning" if risk >= 55 else "Monitor water level"
        explanation = "Water level and rainfall trend indicate flood-risk escalation." if risk >= 50 else "Water level remains within the monitored range."
    elif h == "fire":
        temp = t.temperature or 0; smoke = t.smoke or 0; hum = t.humidity if t.humidity is not None else 50
        risk = min(98, 5 + max(0, temp-30)*1.7 + smoke*8 + max(0, 35-hum)*.5)
        confidence = min(98, 85 + risk * .07)
        action = "Dispatch patrol" if risk >= 55 else "Monitor zone"
        explanation = "Heat, smoke and humidity signals suggest elevated fire risk." if risk >= 50 else "Environmental fire indicators are stable."
    elif h == "pollution":
        pm = t.pm25 or 0; gas = t.gas or 0; aqi = t.aqi or 0
        risk = min(98, 5 + pm*.38 + gas*5 + aqi*.12)
        confidence = min(98, 84 + risk * .08)
        action = "Notify authority" if risk >= 55 else "Monitor air quality"
        explanation = "Particulate/gas indicators suggest a developing pollution event." if risk >= 50 else "Air-quality indicators remain stable."
    else:
        raise HTTPException(400, f"Unsupported hazard '{t.hazard}'. Use conductor, flood, fire, or pollution.")
    state = "high" if risk >= 70 else "medium" if risk >= 40 else "low"
    return {"risk": round(risk,1), "confidence": round(confidence,1), "state": state, "action": action, "explanation": explanation}

@app.get("/api/health")
def health():
    return {"status":"ok", "service":"bhoorakshak-api", "database":"sqlite", "timestamp":now_iso()}

@app.get("/api/nodes")
def nodes():
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM nodes ORDER BY node_id")]

@app.get("/api/telemetry/{node_id}")
def telemetry(node_id: str, limit: int = Query(50, ge=1, le=500)):
    with conn() as c:
        rows = c.execute("SELECT * FROM telemetry WHERE node_id=? ORDER BY id DESC LIMIT ?", (node_id,limit)).fetchall()
        return [dict(r, payload=json.loads(r["payload"])) for r in rows]

@app.get("/api/predictions/latest")
def predictions_latest():
    with conn() as c:
        rows = c.execute("""SELECT p.* FROM predictions p INNER JOIN
          (SELECT node_id, MAX(id) id FROM predictions GROUP BY node_id) x ON p.id=x.id
          ORDER BY p.risk DESC""").fetchall()
        return [dict(r) for r in rows]

@app.get("/api/alerts")
def alerts(limit: int = Query(50, ge=1, le=200)):
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,))]

@app.post("/api/alerts/{alert_id}/ack")
def ack_alert(alert_id: int):
    with conn() as c:
        cur = c.execute("UPDATE alerts SET acknowledged=1 WHERE id=?", (alert_id,))
        if cur.rowcount == 0: raise HTTPException(404, "Alert not found")
    return {"ok":True, "alert_id":alert_id}

@app.post("/api/telemetry")
def ingest(t: Telemetry):
    if t.hazard.lower() not in HAZARDS:
        raise HTTPException(400, "hazard must be conductor, flood, fire, or pollution")
    ts = (t.timestamp or datetime.now(timezone.utc)).isoformat()
    result = predict(t)
    payload = t.model_dump(mode="json")
    with conn() as c:
        c.execute("""INSERT INTO nodes(node_id,hazard,latitude,longitude,battery,status,last_seen)
                     VALUES(?,?,?,?,?,'online',?) ON CONFLICT(node_id) DO UPDATE SET hazard=excluded.hazard,
                     latitude=excluded.latitude, longitude=excluded.longitude, battery=excluded.battery,
                     status='online', last_seen=excluded.last_seen""",
                  (t.node_id,t.hazard,t.latitude,t.longitude,t.battery,ts))
        c.execute("INSERT INTO telemetry(node_id,hazard,timestamp,latitude,longitude,battery,payload) VALUES(?,?,?,?,?,?,?)",
                  (t.node_id,t.hazard,ts,t.latitude,t.longitude,t.battery,json.dumps(payload)))
        c.execute("INSERT INTO predictions(node_id,hazard,timestamp,risk,confidence,state,action,explanation) VALUES(?,?,?,?,?,?,?,?)",
                  (t.node_id,t.hazard,ts,result["risk"],result["confidence"],result["state"],result["action"],result["explanation"]))
        alert_id = None
        if result["risk"] >= 70:
            sev = "critical" if result["risk"] >= 85 else "high"
            msg = f"{t.hazard.title()} risk {result['risk']}% at {t.node_id}. {result['action']}."
            cur = c.execute("INSERT INTO alerts(node_id,hazard,timestamp,severity,message) VALUES(?,?,?,?,?)",
                            (t.node_id,t.hazard,ts,sev,msg))
            alert_id = cur.lastrowid
    return {"accepted":True, "node_id":t.node_id, "prediction":result, "alert_id":alert_id, "timestamp":ts}

@app.post("/api/simulate/{hazard}")
def simulate(hazard: str):
    samples = {
      "conductor": Telemetry(node_id="PL-0042",hazard="conductor",latitude=12.83,longitude=79.97,battery=94,voltage=84,current=.9,vibration=2.41),
      "flood": Telemetry(node_id="FL-0018",hazard="flood",latitude=16.52,longitude=80.63,battery=87,water_level=124,rain_rate=31,temperature=30,humidity=76),
      "fire": Telemetry(node_id="FF-0027",hazard="fire",latitude=11.63,longitude=76.08,battery=91,temperature=53,smoke=4.9,humidity=22),
      "pollution": Telemetry(node_id="PN-0183",hazard="pollution",latitude=17.39,longitude=78.49,battery=76,pm25=146,gas=4.9,aqi=198,temperature=34,humidity=48),
    }
    if hazard not in samples: raise HTTPException(400, "Unsupported hazard")
    return ingest(samples[hazard])

# Serve the actual website from the same application so one command runs the whole prototype.
if FRONTEND.exists():
    app.mount("/assets", StaticFiles(directory=FRONTEND), name="assets")

@app.get("/")
def website():
    return FileResponse(FRONTEND / "index.html")
